/*
 Laboratorio de Computacion II
 */

package ej_geometria;


public abstract class Figura {
   abstract float calculaArea();    
}
