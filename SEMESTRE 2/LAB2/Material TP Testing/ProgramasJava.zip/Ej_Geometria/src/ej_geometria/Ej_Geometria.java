/*
Laboratorio de Computacion II
 */

package ej_geometria;

/**
 *
 * @author jmonetti
 */
public class Ej_Geometria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
