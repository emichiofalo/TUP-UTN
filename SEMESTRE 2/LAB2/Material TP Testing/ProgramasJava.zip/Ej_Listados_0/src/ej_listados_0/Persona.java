/*
 Laboratorio de Computacion II
 */

package ej_listados_0;

/**
 *
 * @author jmonetti
 */
public class Persona {
    String Nombre;
    char sexo;
    String documento;
    
    public Persona(String Nombre, char sexo, String documento) {
      this.Nombre = Nombre;
      this.sexo = sexo;
      this.documento = documento;
    }
    
}
