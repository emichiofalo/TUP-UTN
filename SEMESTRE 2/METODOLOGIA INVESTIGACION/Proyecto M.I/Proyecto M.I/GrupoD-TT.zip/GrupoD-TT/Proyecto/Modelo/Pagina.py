class Pagina:

    ancho: int = 0
    alto: int = 0
    cobertura: float = 0.0

    def __init__(self, ancho, alto, cobertura):
        self.ancho = ancho
        self.alto = alto
        self.cobertura = cobertura