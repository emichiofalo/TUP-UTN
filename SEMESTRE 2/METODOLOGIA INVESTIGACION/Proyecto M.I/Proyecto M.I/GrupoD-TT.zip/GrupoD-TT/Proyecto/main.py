import tkinter as tk

from Vista.Principal import Principal

main = tk.Tk()
app = Principal(main)
app.mainloop()
