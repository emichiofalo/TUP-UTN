.. pdf2image documentation master file, created by
   sphinx-quickstart on Sat Feb  2 10:46:02 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pdf2image's documentation
========================================================

pdf2image is a python module that wraps the pdftoppm and pdftocairo utilities to convert PDF into images.

If you are new to the project, start with the installation section!

.. toctree::
   :maxdepth: 2

   installation
   overview
   reference
