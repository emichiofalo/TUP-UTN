/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package java2mysql;

/**
 *
 * @author Cristian
 */
public class Java2Mysql {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Servicio nuevo = new Servicio();
        nuevo.verTodos();
    }
}
