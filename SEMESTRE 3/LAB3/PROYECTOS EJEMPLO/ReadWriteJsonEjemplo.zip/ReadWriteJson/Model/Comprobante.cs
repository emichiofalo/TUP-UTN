﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReadWriteJson.Model
{
    public class Comprobante
    {
        public string NroComprobante { get; set; }
        public double Total { get; set; }
    }
}
