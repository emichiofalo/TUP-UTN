﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReadWriteJson.Model
{
    public class Pais
    {
        public string Nombre { get; set; }
        public string Codigo { get; set; }



    }
}
