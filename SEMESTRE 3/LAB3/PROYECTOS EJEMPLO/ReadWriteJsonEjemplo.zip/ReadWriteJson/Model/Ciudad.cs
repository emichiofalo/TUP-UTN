﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReadWriteJson.Model
{
    public class Ciudad
    {
        public string Nombre { get; set; }
        public Pais Pais { get; set; }
    }
}
